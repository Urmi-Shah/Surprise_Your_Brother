# love-and-surprise-
🌟 Project Showcase: A Special HTML, CSS &amp; JS Creation! 🌟Just finished this fun project where I used HTML, CSS, and JavaScript to create something special. It’s a digital message for happy rakshabandhan brother : "I Love You." ❤

To replace name "SMIT SHAH" on 1st page  to your brother name go to "index.html " 

To replace any book image goto "book.html" file.

	 book cover photo - line 26 replace main4.jpeg with your image and adjust it height width.

	 book 1st img - line 70

	 book 2nd img - line 90

	 book 3rd img - line 101

	 book 4th img - line 106

	 book 5th img - line 113

	 book 6th img - line 123

	 book 7th img - line 133

	 book 8th img - line 143

	 book 9th img - line 151
	 
	 book 10th img - line 161
	 
	 book 11th img - line 171
	 
	 book 12th img - line 181
	 
	 book 13th img - line 189
	
To Replace 1st page Background "https://www.canva.com/design/DAGNcvqSh_E/TWdBWlEuMDrSU4whft7peQ/edit?utm_content=DAGNcvqSh_E&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton "

edit this

Check it out and let me know what you think
